﻿namespace Week_05_Amira_Nafisha_Tsaqifa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Product = new System.Windows.Forms.Label();
            this.dataGridView_Product = new System.Windows.Forms.DataGridView();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.comboBox_Filter = new System.Windows.Forms.ComboBox();
            this.lb_Details = new System.Windows.Forms.Label();
            this.lb_Nama_Details = new System.Windows.Forms.Label();
            this.lb_CategoryDetails = new System.Windows.Forms.Label();
            this.lb_Harga_Details = new System.Windows.Forms.Label();
            this.lb_Stock_Details = new System.Windows.Forms.Label();
            this.textBox_Nama_Details = new System.Windows.Forms.TextBox();
            this.textBox_Harga = new System.Windows.Forms.TextBox();
            this.textBox_Stock = new System.Windows.Forms.TextBox();
            this.comboBox_Category = new System.Windows.Forms.ComboBox();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.lb_Category = new System.Windows.Forms.Label();
            this.dataGridView_Category = new System.Windows.Forms.DataGridView();
            this.lb_Nama_Category = new System.Windows.Forms.Label();
            this.textBox_Nama_Category = new System.Windows.Forms.TextBox();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(29, 31);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(86, 25);
            this.lb_Product.TabIndex = 0;
            this.lb_Product.Text = "Product";
            // 
            // dataGridView_Product
            // 
            this.dataGridView_Product.AllowUserToAddRows = false;
            this.dataGridView_Product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Product.Location = new System.Drawing.Point(34, 95);
            this.dataGridView_Product.Name = "dataGridView_Product";
            this.dataGridView_Product.RowHeadersVisible = false;
            this.dataGridView_Product.RowHeadersWidth = 62;
            this.dataGridView_Product.RowTemplate.Height = 28;
            this.dataGridView_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Product.Size = new System.Drawing.Size(746, 254);
            this.dataGridView_Product.TabIndex = 1;
            this.dataGridView_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Product_CellClick_1);
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(450, 32);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(89, 32);
            this.btn_All.TabIndex = 2;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(545, 32);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(89, 32);
            this.btn_Filter.TabIndex = 3;
            this.btn_Filter.Text = "Filter";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // comboBox_Filter
            // 
            this.comboBox_Filter.FormattingEnabled = true;
            this.comboBox_Filter.Location = new System.Drawing.Point(640, 32);
            this.comboBox_Filter.Name = "comboBox_Filter";
            this.comboBox_Filter.Size = new System.Drawing.Size(121, 28);
            this.comboBox_Filter.TabIndex = 4;
            this.comboBox_Filter.SelectedIndexChanged += new System.EventHandler(this.comboBox_Filter_SelectedIndexChanged);
            // 
            // lb_Details
            // 
            this.lb_Details.AutoSize = true;
            this.lb_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Details.Location = new System.Drawing.Point(29, 394);
            this.lb_Details.Name = "lb_Details";
            this.lb_Details.Size = new System.Drawing.Size(78, 25);
            this.lb_Details.TabIndex = 5;
            this.lb_Details.Text = "Details";
            // 
            // lb_Nama_Details
            // 
            this.lb_Nama_Details.AutoSize = true;
            this.lb_Nama_Details.Location = new System.Drawing.Point(33, 437);
            this.lb_Nama_Details.Name = "lb_Nama_Details";
            this.lb_Nama_Details.Size = new System.Drawing.Size(59, 20);
            this.lb_Nama_Details.TabIndex = 6;
            this.lb_Nama_Details.Text = "Nama :";
            // 
            // lb_CategoryDetails
            // 
            this.lb_CategoryDetails.AutoSize = true;
            this.lb_CategoryDetails.Location = new System.Drawing.Point(30, 485);
            this.lb_CategoryDetails.Name = "lb_CategoryDetails";
            this.lb_CategoryDetails.Size = new System.Drawing.Size(81, 20);
            this.lb_CategoryDetails.TabIndex = 7;
            this.lb_CategoryDetails.Text = "Category :";
            // 
            // lb_Harga_Details
            // 
            this.lb_Harga_Details.AutoSize = true;
            this.lb_Harga_Details.Location = new System.Drawing.Point(33, 528);
            this.lb_Harga_Details.Name = "lb_Harga_Details";
            this.lb_Harga_Details.Size = new System.Drawing.Size(61, 20);
            this.lb_Harga_Details.TabIndex = 8;
            this.lb_Harga_Details.Text = "Harga :";
            // 
            // lb_Stock_Details
            // 
            this.lb_Stock_Details.AutoSize = true;
            this.lb_Stock_Details.Location = new System.Drawing.Point(33, 575);
            this.lb_Stock_Details.Name = "lb_Stock_Details";
            this.lb_Stock_Details.Size = new System.Drawing.Size(58, 20);
            this.lb_Stock_Details.TabIndex = 9;
            this.lb_Stock_Details.Text = "Stock :";
            // 
            // textBox_Nama_Details
            // 
            this.textBox_Nama_Details.Location = new System.Drawing.Point(120, 431);
            this.textBox_Nama_Details.Name = "textBox_Nama_Details";
            this.textBox_Nama_Details.Size = new System.Drawing.Size(394, 26);
            this.textBox_Nama_Details.TabIndex = 10;
            // 
            // textBox_Harga
            // 
            this.textBox_Harga.Location = new System.Drawing.Point(120, 522);
            this.textBox_Harga.Name = "textBox_Harga";
            this.textBox_Harga.Size = new System.Drawing.Size(118, 26);
            this.textBox_Harga.TabIndex = 11;
            // 
            // textBox_Stock
            // 
            this.textBox_Stock.Location = new System.Drawing.Point(120, 566);
            this.textBox_Stock.Name = "textBox_Stock";
            this.textBox_Stock.Size = new System.Drawing.Size(118, 26);
            this.textBox_Stock.TabIndex = 12;
            // 
            // comboBox_Category
            // 
            this.comboBox_Category.FormattingEnabled = true;
            this.comboBox_Category.Location = new System.Drawing.Point(120, 477);
            this.comboBox_Category.Name = "comboBox_Category";
            this.comboBox_Category.Size = new System.Drawing.Size(118, 28);
            this.comboBox_Category.TabIndex = 13;
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_AddProduct.Location = new System.Drawing.Point(244, 522);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(86, 56);
            this.btn_AddProduct.TabIndex = 14;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = false;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_EditProduct.Location = new System.Drawing.Point(336, 522);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(86, 56);
            this.btn_EditProduct.TabIndex = 15;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveProduct.Location = new System.Drawing.Point(428, 522);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(86, 56);
            this.btn_RemoveProduct.TabIndex = 16;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = false;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(830, 31);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(100, 25);
            this.lb_Category.TabIndex = 17;
            this.lb_Category.Text = "Category";
            // 
            // dataGridView_Category
            // 
            this.dataGridView_Category.AllowUserToAddRows = false;
            this.dataGridView_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Category.Location = new System.Drawing.Point(835, 95);
            this.dataGridView_Category.Name = "dataGridView_Category";
            this.dataGridView_Category.RowHeadersVisible = false;
            this.dataGridView_Category.RowHeadersWidth = 62;
            this.dataGridView_Category.RowTemplate.Height = 28;
            this.dataGridView_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Category.Size = new System.Drawing.Size(306, 209);
            this.dataGridView_Category.TabIndex = 18;
            this.dataGridView_Category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Category_CellClick);
            
            // 
            // lb_Nama_Category
            // 
            this.lb_Nama_Category.AutoSize = true;
            this.lb_Nama_Category.Location = new System.Drawing.Point(831, 329);
            this.lb_Nama_Category.Name = "lb_Nama_Category";
            this.lb_Nama_Category.Size = new System.Drawing.Size(59, 20);
            this.lb_Nama_Category.TabIndex = 19;
            this.lb_Nama_Category.Text = "Nama :";
            // 
            // textBox_Nama_Category
            // 
            this.textBox_Nama_Category.Location = new System.Drawing.Point(889, 326);
            this.textBox_Nama_Category.Name = "textBox_Nama_Category";
            this.textBox_Nama_Category.Size = new System.Drawing.Size(252, 26);
            this.textBox_Nama_Category.TabIndex = 20;
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_AddCategory.Location = new System.Drawing.Point(963, 363);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(86, 56);
            this.btn_AddCategory.TabIndex = 21;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveCategory.Location = new System.Drawing.Point(1055, 363);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(86, 56);
            this.btn_RemoveCategory.TabIndex = 22;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = false;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1178, 604);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.textBox_Nama_Category);
            this.Controls.Add(this.lb_Nama_Category);
            this.Controls.Add(this.dataGridView_Category);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.comboBox_Category);
            this.Controls.Add(this.textBox_Stock);
            this.Controls.Add(this.textBox_Harga);
            this.Controls.Add(this.textBox_Nama_Details);
            this.Controls.Add(this.lb_Stock_Details);
            this.Controls.Add(this.lb_Harga_Details);
            this.Controls.Add(this.lb_CategoryDetails);
            this.Controls.Add(this.lb_Nama_Details);
            this.Controls.Add(this.lb_Details);
            this.Controls.Add(this.comboBox_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.dataGridView_Product);
            this.Controls.Add(this.lb_Product);
            this.Name = "Form1";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Product;
        private System.Windows.Forms.DataGridView dataGridView_Product;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.ComboBox comboBox_Filter;
        private System.Windows.Forms.Label lb_Details;
        private System.Windows.Forms.Label lb_Nama_Details;
        private System.Windows.Forms.Label lb_CategoryDetails;
        private System.Windows.Forms.Label lb_Harga_Details;
        private System.Windows.Forms.Label lb_Stock_Details;
        private System.Windows.Forms.TextBox textBox_Nama_Details;
        private System.Windows.Forms.TextBox textBox_Harga;
        private System.Windows.Forms.TextBox textBox_Stock;
        private System.Windows.Forms.ComboBox comboBox_Category;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.DataGridView dataGridView_Category;
        private System.Windows.Forms.Label lb_Nama_Category;
        private System.Windows.Forms.TextBox textBox_Nama_Category;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Button btn_RemoveCategory;
    }
}

