﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_05_Amira_Nafisha_Tsaqifa
{
    public partial class Form1 : Form
    {
        private DataTable dtProdukSimpan;
        private DataTable dtProdukTampil;
        private DataTable dtCategory;
        private bool isCategoryCellClickEnabled = false;

        public Form1()
        {
            InitializeComponent();
            dtProdukSimpan = new DataTable();
            dtProdukTampil = new DataTable();
            dtCategory = new DataTable();

            dtProdukSimpan.Columns.Add("ID Product", typeof(string));
            dtProdukSimpan.Columns.Add("Nama Product", typeof(string));
            dtProdukSimpan.Columns.Add("Harga", typeof(decimal));
            dtProdukSimpan.Columns.Add("Stock", typeof(int));
            dtProdukSimpan.Columns.Add("ID Category", typeof(string));

            dtCategory.Columns.Add("ID Category", typeof(string));
            dtCategory.Columns.Add("Nama Category", typeof(string));

            AddCategory("Jas");
            AddCategory("T-Shirt");
            AddCategory("Rok");
            AddCategory("Celana");
            AddCategory("Cawat");

            comboBox_Category.Items.Add("Jas");
            comboBox_Category.Items.Add("T-Shirt");
            comboBox_Category.Items.Add("Rok");
            comboBox_Category.Items.Add("Celana");
            comboBox_Category.Items.Add("Cawat");

            comboBox_Filter.DataSource = dtCategory;
            comboBox_Filter.DisplayMember = "Nama Category";
            comboBox_Filter.ValueMember = "ID Category";

            dataGridView_Category.DataSource = dtCategory;

            foreach (DataRow row in dtCategory.Rows)
            {
                Console.WriteLine($"{row["ID Category"]}: {row["Nama Category"]}");
            }

            comboBox_Filter.SelectedIndex = -1;

            comboBox_Filter.Enabled = false;

            dataGridView_Product.ReadOnly = true;

            dataGridView_Product.MultiSelect = false;
            dataGridView_Product.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            dataGridView_Category.MultiSelect = false;
            dataGridView_Category.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            isCategoryCellClickEnabled = true;

            dataGridView_Category.ClearSelection();

            textBox_Harga.KeyPress += new KeyPressEventHandler(textBox_Harga_KeyPress);
            textBox_Stock.KeyPress += new KeyPressEventHandler(textBox_Stock_KeyPress);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AddProduct(dtProdukSimpan, "Jas Hitam", 100000, 10, "C1");
            AddProduct(dtProdukSimpan, "T-Shirt Black Pink", 70000, 20, "C2");
            AddProduct(dtProdukSimpan, "T-Shirt Obsessive", 75000, 16, "C2");
            AddProduct(dtProdukSimpan, "Rok mini", 82000, 26, "C3");
            AddProduct(dtProdukSimpan, "Jeans Biru", 90000, 5, "C4");
            AddProduct(dtProdukSimpan, "Celana Pendek Cargo", 60000, 11, "C4");
            AddProduct(dtProdukSimpan, "Cawat Blink-blink", 1000000, 1, "C5");
            AddProduct(dtProdukSimpan, "Rocca Shirt", 50000, 8, "C2");

            dataGridView_Product.DataSource = dtProdukSimpan;

            dataGridView_Product.ClearSelection();
            dataGridView_Category.ClearSelection();
        }

        private void textBox_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void textBox_Stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void AddProduct(DataTable dt, string productName, decimal harga, int stock, string idCategory)
        {
            DataRow newRow = dt.NewRow();
            newRow["ID Product"] = GenerateProductID(productName);
            newRow["Nama Product"] = productName;
            newRow["Harga"] = harga;
            newRow["Stock"] = stock;
            newRow["ID Category"] = idCategory;
            dt.Rows.Add(newRow);
        }
        private void AddCategory(string categoryName)
        {
            string categoryID = GenerateCategoryID();

            DataRow newRow = dtCategory.NewRow();
            newRow["ID Category"] = categoryID;
            newRow["Nama Category"] = categoryName;
            dtCategory.Rows.Add(newRow);
        }

        private string GenerateCategoryID()
        {
            int maxCategoryID = 0;

            foreach (DataRow row in dtCategory.Rows)
            {
                int categoryID = int.Parse(row["ID Category"].ToString().Substring(1));
                if (categoryID > maxCategoryID)
                {
                    maxCategoryID = categoryID;
                }
            }

            return "C" + (maxCategoryID + 1);
        }

        private string GenerateProductID(string productName)
        {
            char firstChar = productName.ToUpper()[0];
            int count = 1;
            string prefix = firstChar.ToString();
            foreach (DataRow row in dtProdukSimpan.Rows)
            {
                int currentID = int.Parse(row[0].ToString ().Substring(1));
                string id = row["ID Product"].ToString();
                if (id.StartsWith(prefix))
                {
                    if (currentID >= count)
                    {
                        count = currentID + 1;
                    }
                }
            }
            return $"{prefix}{count:D3}";
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            comboBox_Filter.Enabled = true;

            if (comboBox_Filter.SelectedItem != null)
            {
                string selectedCategory = comboBox_Filter.SelectedValue.ToString();
                DataView dv = new DataView(dtProdukSimpan);
                dv.RowFilter = $"[ID Category] = '{selectedCategory}'";
                dtProdukTampil = dv.ToTable();
                dataGridView_Product.DataSource = dtProdukTampil;
            }
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            comboBox_Filter.Enabled = false;

            comboBox_Filter.Text = "";

            dataGridView_Product.DataSource = dtProdukSimpan;
        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            string namaProduk = textBox_Nama_Details.Text;
            string kategori = comboBox_Category.Text;
            decimal harga = 0;
            int stok = 0;
            string IDCategory = "";

            if (!string.IsNullOrWhiteSpace(textBox_Harga.Text) && decimal.TryParse(textBox_Harga.Text, out harga) &&
                !string.IsNullOrWhiteSpace(textBox_Stock.Text) && int.TryParse(textBox_Stock.Text, out stok))
            {
                if (string.IsNullOrWhiteSpace(kategori))
                {
                    MessageBox.Show("Pilih kategori produk.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DataRow newRow = dtProdukSimpan.NewRow();

                for (int i = 0; i < dtCategory.Columns.Count; i++)
                {
                    for (int j = 0; j < dtCategory.Rows.Count; j++)
                    {
                        if (comboBox_Category.Text == dtCategory.Rows[j][1].ToString())
                        {
                            IDCategory = dtCategory.Rows[j][0].ToString();
                        }
                    }
                }

                newRow["ID Product"] = GenerateProductID(namaProduk);
                newRow["Nama Product"] = namaProduk;
                newRow["Harga"] = harga;
                newRow["Stock"] = stok;
                newRow["ID Category"] = IDCategory;

                dtProdukSimpan.Rows.Add(newRow);

                dtProdukSimpan.AcceptChanges();

                textBox_Nama_Details.Text = "";
                comboBox_Category.SelectedIndex = -1;
                textBox_Harga.Text = "";
                textBox_Stock.Text = "";
            }
            else
            {
                MessageBox.Show("Pilih produk yang ingin ditambahkan.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            dataGridView_Product.ClearSelection();
        }

        private void comboBox_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = comboBox_Filter.SelectedValue?.ToString();

            DataView dv = new DataView(dtProdukSimpan);

            dv.RowFilter = $"[ID Category] = '{selectedCategory}'";
            dataGridView_Product.DataSource = dv.ToTable();
            
        }

        private void dataGridView_Product_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView_Product.CurrentRow;
                string a = "";
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (selectedRow.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                    {
                        a = dtCategory.Rows[i][1].ToString();break;
                    }
                }

                textBox_Nama_Details.Text = selectedRow.Cells[1].Value.ToString();
                comboBox_Category.Text = a;
                textBox_Harga.Text = selectedRow.Cells[2].Value.ToString();
                textBox_Stock.Text = selectedRow.Cells[3].Value.ToString();
            }
        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (dataGridView_Product.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView_Product.SelectedRows[0].Index;

                string editedProductName = textBox_Nama_Details.Text;
                string editedCategory = comboBox_Category.Text;
                decimal editedHarga = decimal.Parse(textBox_Harga.Text);
                int editedStock = int.Parse(textBox_Stock.Text);

                DataRow selectedRow = dtProdukSimpan.Rows[selectedIndex];
                selectedRow["Nama Product"] = editedProductName;
                selectedRow["ID Category"] = editedCategory;
                selectedRow["Harga"] = editedHarga;
                selectedRow["Stock"] = editedStock;

                if (editedStock == 0)
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedIndex);
                }

                dataGridView_Product.Refresh();

                textBox_Nama_Details.Text = "";
                comboBox_Category.SelectedIndex = -1;
                textBox_Harga.Text = "";
                textBox_Stock.Text = "";
            }
            else
            {
                MessageBox.Show("Pilih produk yang ingin diedit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            dataGridView_Product.ClearSelection();
        }

        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            if (dataGridView_Product.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView_Product.SelectedRows[0].Index;

                dtProdukSimpan.Rows.RemoveAt(selectedIndex);

                dataGridView_Product.AllowUserToAddRows = false;

                dataGridView_Product.ClearSelection();

                dataGridView_Product.DataSource = null;
                dataGridView_Product.DataSource = dtProdukSimpan;

                dataGridView_Product.AllowUserToAddRows = true;
                textBox_Nama_Details.Text = "";
                comboBox_Category.SelectedIndex = -1;
                textBox_Harga.Text = "";
                textBox_Stock.Text = "";
                dataGridView_Product.ClearSelection();
            }
            else
            {
                MessageBox.Show("Pilih produk yang ingin dihapus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox_Nama_Category.Text))
            {
                string newCategoryName = textBox_Nama_Category.Text.Trim();

                bool categoryExists = dtCategory.AsEnumerable()
                                            .Any(row => string.Equals(row.Field<string>("Nama Category"), newCategoryName, StringComparison.OrdinalIgnoreCase));

                if (!categoryExists)
                {
                    string newCategoryID = GenerateCategoryID();
                    DataRow newRow = dtCategory.NewRow();
                    newRow["ID Category"] = newCategoryID;
                    newRow["Nama Category"] = newCategoryName;
                    dtCategory.Rows.Add(newRow);

                    textBox_Nama_Category.Text = "";
                }
                else
                {
                    MessageBox.Show("Kategori dengan nama yang sama sudah ada.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Nama kategori tidak boleh kosong.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            dataGridView_Category.ClearSelection();
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (dataGridView_Category.SelectedRows.Count > 0)
            {
                string selectedCategoryName = dataGridView_Category.SelectedRows[0].Cells["Nama Category"].Value.ToString();

                DataRow[] selectedCategoryRows = dtCategory.Select($"[Nama Category] = '{selectedCategoryName}'");
                foreach (DataRow row in selectedCategoryRows)
                {
                    dtCategory.Rows.Remove(row);
                }

                DataRow[] selectedProductRows = dtProdukSimpan.Select($"[ID Category] = '{selectedCategoryName}'");
                foreach (DataRow row in selectedProductRows)
                {
                    row.Delete();
                }

                dataGridView_Product.DataSource = dtProdukSimpan;

                dataGridView_Category.DataSource = dtCategory;
                dataGridView_Category.ClearSelection();

                textBox_Nama_Category.Text = "" ;
            }
            else
            {
                MessageBox.Show("Pilih kategori yang ingin dihapus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string categoryName = dataGridView_Category.Rows[e.RowIndex].Cells["Nama Category"].Value.ToString();
            textBox_Nama_Category.Text = categoryName;
        }
    }
}